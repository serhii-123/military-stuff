module.exports = async function(req, res) {
    res.render('product.hbs')
}